"""Frozen administrative documents and dependency-free, printable PDF output."""
import json
import textwrap
from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
from .db import ValidationError, audit, integer, money, required, valid_date, local_today
from .branding import pdf_logo
from .pdf_fonts import embed_fonts, text_width


def converted(cents, rate):
    return int((Decimal(cents) * Decimal(rate)).quantize(Decimal('1'), rounding=ROUND_HALF_UP))


def student_status(record):
    if record.get('archived'): return 'Inactivo · Archivado'
    return {'active':'Activo','inactive':'Inactivo'}.get(record.get('status'),'Estado no registrado')


def amount(cents, currency='USD'):
    value = f'{cents // 100:,}.{cents % 100:02d}'.translate(str.maketrans({',':'.', '.':','}))
    return f'{currency} {value}'


SHORT_MONTHS = ('ENE', 'FEB', 'MAR', 'ABR', 'MAY', 'JUN', 'JUL', 'AGO', 'SEP', 'OCT', 'NOV', 'DIC')


def school_month(value):
    try:
        parsed = datetime.strptime(value, '%Y-%m')
        return f'{SHORT_MONTHS[parsed.month-1]}. {parsed.year:04d}'
    except (ValueError, TypeError):
        return 'Pendiente'


def school_birth_date(value):
    try:
        parsed = datetime.strptime(value, '%Y-%m-%d')
        if parsed.year < 1900:
            return 'Pendiente'
        return f'{parsed.day:02d} {school_month(value[:7])}'
    except (ValueError, TypeError):
        return 'Pendiente'


def enrollment(db, student_id, user_id):
    row = db.execute('''SELECT s.*,g.name AS guardian_name,g.document AS guardian_document,
        g.phone AS guardian_phone,g.email AS guardian_email,g.address AS guardian_address,
        gr.name AS grade_name FROM students s JOIN guardians g ON g.id=s.guardian_id
        JOIN grades gr ON gr.id=s.grade_id WHERE s.id=?''', (student_id,)).fetchone()
    data = {'student': dict(row), 'school': dict(db.execute('SELECT key,value FROM settings'))}
    data['student']['net_fee'] = (row['monthly_fee'] * (100-row['discount']) + 50)//100
    return store(db, 'enrollment_documents', data, user_id, student_id)


def store(db, table, data, user_id, student_id=None):
    created = datetime.now(timezone.utc).isoformat()
    data['created_at'] = created
    data['issued_on'] = local_today().isoformat()
    data['operator'] = db.execute('SELECT name FROM users WHERE id=?', (user_id,)).fetchone()[0]
    fields, values = 'snapshot_json,created_at,created_by', [json.dumps(data, ensure_ascii=False), created, user_id]
    if student_id is not None:
        fields += ',student_id'
        values.append(student_id)
    if table == 'enrollment_documents':
        from .db import next_record_id
        fields += ',id'
        values.append(next_record_id(db, table))
    result = db.execute(f'INSERT INTO {table}({fields}) VALUES({",".join("?" for _ in values)})', values)
    audit(db, user_id, table, {'id': result.lastrowid})
    return result.lastrowid


def load_document(db, kind, target):
    table = {'enrollment': 'enrollment_documents'}[kind]
    row = db.execute(f'SELECT snapshot_json FROM {table} WHERE id=?', (target,)).fetchone()
    if not row:
        raise ValidationError('Documento inexistente.')
    return dict(json.loads(row[0]), id=target)


class PDF:
    """Small vector PDF writer: WinAnsi fonts, wrapping and repeating table headings."""
    def __init__(self, title, school, landscape=False):
        self.w, self.h = (842, 595) if landscape else (595, 842)
        self.title, self.school, self.pages = title, school, []
        self.logo = pdf_logo(school.get('logo', ''))
        self.new_page()

    def text(self, x, y, value, size=10, bold=False, color='0.10 0.18 0.32'):
        raw = str(value).encode('cp1252', errors='replace')
        escaped = ''.join(f'\\{b:03o}' if b<32 or b>126 else ('\\'+chr(b) if chr(b) in '()\\' else chr(b)) for b in raw)
        self.commands.append(f'BT {color} rg /{"F2" if bold else "F1"} {size} Tf 1 0 0 1 {x} {self.h-y} Tm ({escaped}) Tj ET')

    def box(self, x, y, w, h, fill=None):
        if fill:
            self.commands.append(f'{fill} rg {x} {self.h-y-h} {w} {h} re f')
        self.commands.append(f'0.18 0.27 0.45 RG 0.6 w {x} {self.h-y-h} {w} {h} re S')

    def new_page(self):
        self.commands = []
        self.pages.append(self.commands)
        self.box(24, 24, self.w-48, self.h-48)
        if self.logo:
            w, h, _ = self.logo
            height, width = 78, 78*w/h
            self.commands.append(f'q {width:.3f} 0 0 {height} 38 {self.h-36-height} cm /Logo Do Q')
        else:
            self.box(38, 36, 40, 40, '0.94 0.96 0.99')
            self.box(46, 44, 12, 22)
            self.box(58, 44, 12, 22)
        x = 126 if self.logo else 90
        width = self.w-x-45
        if self.school.get('institution_type'):self.text(x,33,self.school['institution_type'],8,True)
        name_lines = self.wrap(self.school.get('legal_name') or self.school.get('school_name','Colegio'), width, 14)
        for i, line in enumerate(name_lines):
            self.text(x, 49+i*18, line, 14, True)
        header_y = 49+len(name_lines)*18
        if self.school.get('rif'):
            self.text(x, header_y, 'RIF: '+self.school['rif'], 10, True)
            header_y += 15
        address = self.school.get('fiscal_address') or self.school.get('address','')
        for line in self.wrap('Domicilio fiscal: '+address if address else '', width, 9):
            self.text(x, header_y, line, 9)
            header_y += 12
        contact = ' | '.join(str(self.school.get(k,'')) for k in ('phone','email','website') if self.school.get(k))
        for line in self.wrap(contact, width, 8):
            if line:
                self.text(x, header_y, line, 8)
                header_y += 11
        self.y = max(126 if self.logo else 100, header_y+12)
        self.box(38, self.y, self.w-76, 27, '0.94 0.96 0.99')
        self.text(46, self.y+18, self.title, 12, True)
        self.text(self.w-97, self.h-35, f'Página {len(self.pages)}', 8)
        self.y += 42

    @staticmethod
    def wrap(value, width, size=10):
        result = []
        for line in str(value).splitlines() or ['']:
            result.extend(textwrap.wrap(line, max(1, int(width/(size*.56)))) or [''])
        return result

    def ensure(self, height):
        if self.y+height > self.h-65:
            self.new_page()
            return True
        return False

    def line(self, value, bold=False):
        for line in self.wrap(value, self.w-90):
            self.ensure(17)
            self.text(44, self.y, line, 10, bold)
            self.y += 17

    def table(self, headings, rows, widths):
        def draw(values, header=False):
            cells = [self.wrap(v, width-10, 9) for v, width in zip(values, widths)]
            height = max(len(c) for c in cells)*12+12
            if self.ensure(height) and not header:
                draw(headings, True)
            x = 38
            for cell, width in zip(cells, widths):
                self.box(x, self.y, width, height, '0.94 0.96 0.99' if header else None)
                for i, line in enumerate(cell):
                    self.text(x+5, self.y+15+i*12, line, 9, header)
                x += width
            self.y += height
        draw(headings, True)
        for row in rows:
            draw(row)
        self.y += 23

    def signature(self, left, right, operator):
        self.ensure(90)
        self.y += 32
        width = (self.w-110)/2
        for x, label in ((44,left),(66+width,right)):
            self.commands.append(f'0.35 0.44 0.56 RG 0.5 w {x} {self.h-self.y} m {x+width} {self.h-self.y} l S')
            self.text(x+4, self.y+16, label, 9)
        self.y += 44
        self.line('Registrado por: '+operator)

    def total(self, value):
        lines = self.wrap(value, self.w-100, 12)
        self.ensure(28+18*len(lines))
        height = 14+18*len(lines)
        self.box(38, self.y, self.w-76, height, '0.94 0.96 0.99')
        for i, line in enumerate(lines):
            self.text(46, self.y+21+i*18, line, 12, True)
        self.y += height+24

    def output(self):
        objects = [b'<< /Type /Catalog /Pages 2 0 R >>', b'',
                   b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',
                   b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>']
        if getattr(self, 'embedded_fonts', False):
            embed_fonts(objects)
        kids = []
        logo_resources = ''
        if self.logo:
            w, h, stream = self.logo
            logo_index = len(objects)+1
            objects.append((f'<< /Type /XObject /Subtype /Image /Width {w} /Height {h} '
                f'/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /FlateDecode '
                f'/DecodeParms << /Predictor 15 /Colors 3 /BitsPerComponent 8 /Columns {w} >> '
                f'/Length {len(stream)} >>\nstream\n').encode()+stream+b'\nendstream')
            logo_resources = f' /XObject << /Logo {logo_index} 0 R >>'
        for commands in self.pages:
            index = len(objects)+1
            kids.append(f'{index} 0 R')
            objects.append(f'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {self.w} {self.h}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >>{logo_resources} >> /Contents {index+1} 0 R >>'.encode())
            stream = '\n'.join(commands).encode('ascii')
            objects.append(f'<< /Length {len(stream)} >>\nstream\n'.encode()+stream+b'\nendstream')
        objects[1] = f'<< /Type /Pages /Count {len(kids)} /Kids [{" ".join(kids)}] >>'.encode()
        output = bytearray(b'%PDF-1.4\n%\xe2\xe3\xcf\xd3\n'); offsets = [0]
        for i, obj in enumerate(objects, 1):
            offsets.append(len(output)); output.extend(f'{i} 0 obj\n'.encode()+obj+b'\nendobj\n')
        start = len(output)
        output.extend(f'xref\n0 {len(objects)+1}\n0000000000 65535 f \n'.encode())
        for offset in offsets[1:]:
            output.extend(f'{offset:010d} 00000 n \n'.encode())
        output.extend(f'trailer\n<< /Size {len(objects)+1} /Root 1 0 R >>\nstartxref\n{start}\n%%EOF\n'.encode())
        return bytes(output)


def period_label(value):
    months = ('enero','febrero','marzo','abril','mayo','junio','julio','agosto',
              'septiembre','octubre','noviembre','diciembre')
    try:
        year, month = str(value).split('-')
        if len(year)==4 and year.isascii() and year.isdigit() and len(month)==2 and 1 <= int(month) <= 12:
            return f'{months[int(month)-1].capitalize()} {year}'
    except (ValueError, TypeError):
        pass
    return str(value)


def receipt_student_details(payment):
    name = payment['student_name']
    grade = payment.get('grade_name')
    if grade:
        name += ' · '+grade
    # Keep school identifiers in the record/snapshot, not on the parent receipt.
    return name, '' if grade else 'Grado no registrado'


class ReceiptPDF(PDF):
    """Portrait payment stationery with quiet rules and a prominent received amount."""
    ink = '0.14 0.20 0.29'
    muted = '0.40 0.46 0.53'
    blue = '0.09 0.25 0.40'
    embedded_fonts = True

    def __init__(self, data):
        self.payment = data['payment']
        super().__init__('Comprobante de pago', data['settings'])

    @staticmethod
    def wrap(value, width, size=10):
        # Use the bundled font's real glyph widths, including long unbroken codes.
        # Bold metrics leave enough room for both regular and bold text.
        result = []
        for source in str(value).splitlines() or ['']:
            line = ''
            for word in source.split():
                candidate = line+' '+word if line else word
                if text_width(candidate,size,True)<=width:
                    line = candidate
                    continue
                if line:
                    result.append(line)
                    line = ''
                for character in word:
                    if line and text_width(line+character,size,True)>width:
                        result.append(line)
                        line = ''
                    line += character
            result.append(line)
        return result

    def rule(self, x, y, width):
        self.commands.append(f'0.85 0.89 0.93 RG 0.6 w {x} {self.h-y} m {x+width} {self.h-y} l S')

    def shade(self, x, y, width, height, color='0.95 0.97 0.98'):
        self.commands.append(f'{color} rg {x} {self.h-y-height} {width} {height} re f')

    def paragraph(self, value, x, y, width, size=10, bold=False, color=None):
        for line in self.wrap(value, width, size):
            self.text(x, y, line, size, bold, color or self.ink)
            y += size+4
        return y

    def label(self, value, x, y):
        self.text(x, y, value.upper(), 8, True, self.muted)

    def new_page(self):
        self.commands = []
        self.pages.append(self.commands)
        left, width = 42, self.w-84
        if self.logo:
            w, h, _ = self.logo
            self.commands.append(f'q {64*w/h:.3f} 0 0 64 42 {self.h-104} cm /Logo Do Q')
            x = 120
        else:
            x = left
        if self.school.get('institution_type'):self.text(x,35,self.school['institution_type'],8,True,self.muted)
        y = self.paragraph(self.school.get('legal_name') or self.school.get('school_name','Colegio'),
                           x, 53, self.w-x-42, 12, True, self.blue)
        if self.school.get('rif'):
            self.text(x, y, 'RIF: '+self.school['rif'], 9, True, self.muted)
            y += 15
        address = self.school.get('fiscal_address') or self.school.get('address','')
        if address:
            y = self.paragraph('Domicilio fiscal: '+address, x, y, self.w-x-42, 8.5, color=self.muted)
        contact = ' | '.join(str(self.school.get(k,'')) for k in ('phone','email','website') if self.school.get(k))
        if contact:
            y = self.paragraph(contact, x, y, self.w-x-42, 8, color=self.muted)
        y = max(120, y+14)
        self.rule(left, y, width)
        self.text(left, y+30, self.title, 19, True, self.blue)
        self.text(self.w-143, y+29, f"R-{self.payment['id']:06d}", 13, True, self.blue)
        on = datetime.fromisoformat(self.payment['paid_on']).strftime('%d/%m/%Y')
        self.text(left, y+48, 'Fecha de pago: '+on, 9, color=self.muted)
        if self.payment['voided']:
            self.text(self.w-143, y+48, 'ANULADO', 9, True, '0.65 0.23 0.22')
        self.y = y+77
        self.rule(left, self.h-47, width)
        self.text(left, self.h-32, 'Comprobante administrativo. No sustituye una factura fiscal.', 7.5, color=self.muted)
        self.text(self.w-89, self.h-32, f'Página {len(self.pages)}', 7.5, color=self.muted)

    def parties(self):
        p = self.payment
        name, detail = receipt_student_details(p)
        columns = [('Representante legal',p['guardian_name'],'Cédula: '+p['guardian_document'],p.get('guardian_phone','')),
                   ('Alumno / grado',name,detail,'')]
        sizes = []
        for _, name, document, phone in columns:
            sizes.append(21+len(self.wrap(name,238,11))*15+(len(self.wrap(document,238,9))*13 if document else 0)+
                         (len(self.wrap(phone,238,9))*13 if phone else 0))
        self.ensure(max(sizes)+12)
        bottom = self.y
        for x, (label,name,document,phone) in zip((42,315),columns):
            self.label(label,x,self.y)
            y = self.paragraph(name,x,self.y+21,238,11,True)
            if document:
                y = self.paragraph(document,x,y+1,238,9,color=self.muted)
            if phone:
                y = self.paragraph(phone,x,y,238,9,color=self.muted)
            bottom = max(bottom,y)
        self.y = bottom+17
        if p.get('guardian_address'):
            self.flow('Dirección del representante: '+p['guardian_address'],9,self.muted)
            self.y += 12

    def flow(self, value, size=10, color=None, bold=False):
        for line in self.wrap(value,self.w-84,size):
            self.ensure(size+5)
            self.text(42,self.y,line,size,bold,color or self.ink)
            self.y += size+5

    def allocations(self, rows):
        self.ensure(74)
        self.label('Conceptos abonados',42,self.y)
        self.y += 16
        def header():
            self.shade(42,self.y,self.w-84,27,'0.96 0.97 0.98')
            self.label('Descripción',52,self.y+17)
            self.label('Período',335,self.y+17)
            self.label('Aplicado · USD',454,self.y+17)
            self.y += 27
        header()
        for row in rows:
            descriptions = self.wrap(row['concept'],273,10)
            periods = self.wrap(period_label(row['period']),105,9)
            height = max(len(descriptions)*14,len(periods)*13)+22
            if self.ensure(height+10):
                header()
            y = self.y+19
            for i, line in enumerate(descriptions):
                self.text(52,y+i*14,line,10,color=self.ink)
            for i, line in enumerate(periods):
                self.text(335,y+i*13,line,9,color=self.muted)
            value = amount(row['amount'])
            self.text(self.w-52-text_width(value,10,True),y,value,10,True,self.ink)
            self.y += height
            self.rule(42,self.y,self.w-84)
        self.y += 28

    def payment_summary(self):
        p = self.payment
        reference = self.wrap(p.get('reference',''),225,10) if p.get('reference') else []
        height = max(124 if p['currency']=='VES' else 106,76+len(reference)*14)
        self.ensure(height+15)
        top = self.y
        self.label('Método de pago',42,top+12)
        self.text(42,top+33,p['method'],12,True,self.ink)
        if reference:
            self.label('Referencia / comprobante',42,top+63)
            for i, line in enumerate(reference):
                self.text(42,top+83+i*14,line,10,color=self.ink)
        x, width = 311, 242
        self.shade(x,top,width,height)
        self.label('Importe recibido · '+('Bolívares' if p['currency']=='VES' else 'USD'),x+17,top+23)
        value = amount(p['received_amount'],'Bs' if p['currency']=='VES' else 'USD')
        size = min(23, int(208/(max(1,len(value))*.56)))
        self.text(x+17,top+56,value,size,True,self.blue)
        self.rule(x+17,top+71,width-34)
        self.text(x+17,top+89,'Total aplicado en USD',8.5,color=self.muted)
        applied = amount(p['amount'])
        self.text(self.w-59-text_width(applied,10,True),top+89,applied,10,True,self.blue)
        if p['currency']=='VES':
            self.text(x+17,top+111,f"Tasa BCV aplicada: Bs {p['exchange_rate']} por USD",8,color=self.muted)
        self.y += height+27

    def account_summary(self):
        p = self.payment
        if p.get('balance_after') is None:
            return
        status = 'ABONO' if p['balance_after'] else 'PAGO COMPLETO'
        self.flow(f"{status} | Deuda anterior: {amount(p['balance_before'])} | Aplicado: {amount(p['amount'])}",8,self.blue,True)
        self.flow('Saldo pendiente del alumno: '+amount(p['balance_after']),8,self.blue,True)
        self.flow('Saldo de cargos registrados al cobrar; puede incluir otros meses. No es una constancia de solvencia.',6.5,self.muted)
        self.y += 4

    def render(self, data):
        p = self.payment
        if p['voided']:
            self.flow('COMPROBANTE ANULADO',11,'0.65 0.23 0.22',True)
            self.flow(p['void_reason'],9,'0.65 0.23 0.22')
            self.y += 15
        self.parties()
        self.allocations(data['allocations'])
        self.payment_summary()
        self.account_summary()
        if p['notes']:
            self.ensure(35)
            self.label('Observaciones',42,self.y)
            self.y += 18
            self.flow(p['notes'],9,self.muted)
        self.ensure(100)
        self.y += 44
        for x, label in ((42,'Firma de administración'),(315,'Firma del representante')):
            self.rule(x,self.y,238)
            self.text(x,self.y+17,label,8.5,color=self.muted)
        self.y += 43
        self.flow('Registrado por: '+p['operator'],8,self.muted)
        return self.output()


class HalfLetterReceiptPDF(ReceiptPDF):
    """Readable half-letter portrait stationery, continuing instead of clipping."""
    def __init__(self, data):
        self.payment, self.school = data['payment'], data['settings']
        self.w, self.h, self.pages = 396, 612, []
        self.title = 'Comprobante de pago'
        self.logo = pdf_logo(self.school.get('logo',''))
        self.new_page()

    def paragraph(self, value, x, y, width, size=10, bold=False, color=None):
        for line in self.wrap(value, width, size):
            self.text(x, y, line, size, bold, color or self.ink)
            y += size+2
        return y

    def new_page(self):
        if self.pages:
            self.close_page()
        self.commands = []
        self.pages.append(self.commands)
        x = 14
        if self.logo:
            w,h,_ = self.logo
            self.commands.append(f'q {42*w/h:.3f} 0 0 42 14 {self.h-58} cm /Logo Do Q')
            x = 66
        if self.school.get('institution_type'):self.text(x,12,self.school['institution_type'],7,True,self.muted)
        y = self.paragraph(self.school.get('legal_name') or self.school.get('school_name','Colegio'),x,24,188,11,True,self.blue)
        if self.school.get('rif'):
            self.text(x,y,'RIF: '+self.school['rif'],8,True,self.muted)
            y += 12
        address = self.school.get('fiscal_address') or self.school.get('address','')
        if address:
            y = self.paragraph('Domicilio fiscal: '+address,x,y,188,7.5,color=self.muted)
        contact = ' | '.join(str(self.school.get(k,'')) for k in ('phone','email','website') if self.school.get(k))
        if contact:
            y = self.paragraph(contact,x,y,188,7.5,color=self.muted)
        self.label(self.title,266,24)
        self.text(266,40,f"R-{self.payment['id']:06d}",12,True,self.blue)
        on = datetime.fromisoformat(self.payment['paid_on']).strftime('%d/%m/%Y')
        self.text(266,55,'Fecha: '+on,8,color=self.muted)
        if self.payment['voided']:
            self.text(266,68,'ANULADO',8,True,'0.65 0.23 0.22')
        self.y = max(70,y+1)
        self.rule(14,self.y,368)
        self.y += 9

    def close_page(self):
        bottom = min(self.y+8,590)
        self.rule(14,bottom,368)
        self.text(14,bottom+12,'Comprobante administrativo. No sustituye una factura fiscal.',7,color=self.muted)
        self.text(335,bottom+12,f'Página {len(self.pages)}',7,color=self.muted)

    def ensure(self, height):
        if self.y+height>582:
            self.new_page()
            return True
        return False

    def flow(self,value,size=8.5,color=None,bold=False):
        for line in self.wrap(value,368,size):
            self.ensure(size+3)
            self.text(14,self.y,line,size,bold,color or self.ink)
            self.y += size+3

    def parties(self):
        p = self.payment
        name, detail = receipt_student_details(p)
        contact = ' | Teléfono: '+p['guardian_phone'] if p.get('guardian_phone') else ''
        columns = [('Representante legal',p['guardian_name'],'Cédula: '+p['guardian_document']+contact,''),
                   ('Alumno / grado',name,detail,'')]
        heights = [14+len(self.wrap(name,176,10))*14+(len(self.wrap(document,176,8))*12 if document else 0)+
                   (len(self.wrap(phone,176,8))*12 if phone else 0) for _,name,document,phone in columns]
        self.ensure(max(heights)+6)
        bottom = self.y
        for x,(label,name,document,phone) in zip((14,206),columns):
            self.label(label,x,self.y)
            y = self.paragraph(name,x,self.y+15,176,10,True)
            if document:
                y = self.paragraph(document,x,y,176,8,color=self.muted)
            if phone:
                y = self.paragraph(phone,x,y,176,8,color=self.muted)
            bottom = max(bottom,y)
        self.y = bottom
        if p.get('guardian_address'):
            self.flow('Dirección del representante: '+p['guardian_address'],8,self.muted)
            self.y += 3

    def allocations(self,rows):
        self.ensure(52)
        self.label('Conceptos abonados',14,self.y)
        self.y += 11
        def header():
            self.shade(14,self.y,368,19,'0.96 0.97 0.98')
            for x,value in ((22,'Descripción'),(194,'Período'),(280,'Aplicado · USD')):
                self.label(value,x,self.y+13)
            self.y += 19
        header()
        for row in rows:
            descriptions = self.wrap(row['concept'],166,9)
            periods = self.wrap(period_label(row['period']),74,8)
            height = max(len(descriptions)*12,len(periods)*11)+6
            if self.ensure(height+5):
                header()
            for i,line in enumerate(descriptions):
                self.text(22,self.y+14+i*12,line,9,color=self.ink)
            for i,line in enumerate(periods):
                self.text(194,self.y+14+i*11,line,8,color=self.muted)
            value = amount(row['amount'])
            self.text(374-text_width(value,9,True),self.y+14,value,9,True,self.ink)
            self.y += height
            self.rule(14,self.y,368)
        self.y += 2

    def payment_summary(self):
        p = self.payment
        reference = self.wrap(p.get('reference',''),176,8) if p.get('reference') else []
        height = max(66 if p['currency']=='VES' else 55,42+len(reference)*11)
        self.ensure(height+6)
        top = self.y
        self.label('Método de pago',14,top+9)
        self.text(14,top+22,p['method'],10,True,self.ink)
        if reference:
            self.label('Referencia / comprobante',14,top+36)
            for i,line in enumerate(reference):
                self.text(14,top+49+i*11,line,8,color=self.ink)
        self.shade(206,top,176,height)
        self.label('Importe recibido · '+('Bolívares' if p['currency']=='VES' else 'USD'),219,top+12)
        value = amount(p['received_amount'],'Bs' if p['currency']=='VES' else 'USD')
        self.text(219,top+30,value,18,True,self.blue)
        self.rule(219,top+37,150)
        self.text(219,top+49,'Total aplicado en USD',8,color=self.muted)
        applied = amount(p['amount'])
        self.text(369-text_width(applied,9,True),top+49,applied,9,True,self.blue)
        if p['currency']=='VES':
            self.text(219,top+61,f"Tasa BCV aplicada: Bs {p['exchange_rate']} por USD",7.5,color=self.muted)
        self.y += height+5

    def account_summary(self):
        p = self.payment
        if p.get('balance_after') is None: return
        status = 'ABONO' if p['balance_after'] else 'PAGO COMPLETO'
        self.flow(f"{status} | Deuda al cobrar: {amount(p['balance_before'])} | Aplicado: {amount(p['amount'])} | Pendiente del alumno: {amount(p['balance_after'])}",7,self.blue,True)

    def render(self,data,two_copies=False):
        p = self.payment
        if p['voided']:
            self.flow('ANULADO: '+p['void_reason'],8.5,'0.65 0.23 0.22',True)
            self.y += 5
        self.parties()
        self.allocations(data['allocations'])
        self.payment_summary()
        self.account_summary()
        if p['notes']:
            self.ensure(25)
            self.label('Observaciones',14,self.y)
            self.y += 13
            self.flow(p['notes'],8,self.muted)
        self.ensure(61)
        self.y += 32
        for x,label in ((14,'Firma de administración'),(206,'Firma del representante')):
            self.rule(x,self.y,176)
            self.text(x,self.y+11,label,8,color=self.muted)
        self.y += 18
        self.flow('Registrado por: '+p['operator'],7.5,self.muted)
        self.close_page()
        if two_copies:
            # Reuse the same frozen receipt at 100%, one copy in each half of
            # a landscape letter sheet. This never creates another payment.
            self.w = 792
            labels = []
            for label in ('ORIGINAL', 'COPIA'):
                self.commands = []
                self.text(266,16,label,8,True,self.blue)
                labels.append(self.commands)
            self.pages = [['q'] + page + labels[0] + ['Q', 'q 1 0 0 1 396 0 cm'] + page + labels[1] + ['Q']
                          for page in self.pages]
        return self.output()


class TicketReceiptPDF(ReceiptPDF):
    def __init__(self,data,width):
        self.payment=data['payment'];self.school=data['settings'];self.w=width
        self.logo=pdf_logo(self.school.get('logo',''));self.pages=[]
        self.h=1100
        self.measured=False
        self.new_page()

    def new_page(self):
        self.commands=[];self.pages.append(self.commands);self.y=12
        if self.logo:
            w,h,_=self.logo;self.commands.append(f'q {34*w/h:.3f} 0 0 34 {(self.w-34*w/h)/2:.3f} {self.h-46} cm /Logo Do Q');self.y=59
        for value,size,bold in ((self.school.get('institution_type',''),7,True),(self.school.get('legal_name') or self.school.get('school_name','Colegio'),9,True),
            ('RIF: '+self.school.get('rif',''),7.5,False),(self.school.get('fiscal_address') or self.school.get('address',''),7,False),
            (f"COMPROBANTE R-{self.payment['id']:06d}",9,True),(datetime.fromisoformat(self.payment['paid_on']).strftime('%d/%m/%Y'),8,False)):
            if not value:continue
            for line in self.wrap(value,self.w-18,size):
                self.text(9,self.y,line,size,bold);self.y+=size+3
        if self.payment['voided']:
            self.text(9,self.y,'COMPROBANTE ANULADO',8,True);self.y+=14
        self.rule(9,self.y,self.w-18);self.y+=15

    def ticket_line(self,value,bold=False,size=8):
        for line in self.wrap(value,self.w-18,size):
            if self.y+size+4>self.h-34:self.new_page()
            self.text(9,self.y,line,size,bold);self.y+=size+4

    def render(self,data):
        p=self.payment
        self.ticket_line('REPRESENTANTE',True);self.ticket_line(p['guardian_name'])
        self.ticket_line('Cédula: '+p['guardian_document'])
        self.ticket_line('ALUMNO / GRADO',True)
        name,detail=receipt_student_details(p);self.ticket_line(name)
        if detail:self.ticket_line(detail)
        if p.get('guardian_address'):self.ticket_line('Dirección: '+p['guardian_address'],size=7.5)
        self.y+=6;self.ticket_line('CONCEPTOS ABONADOS',True)
        for row in data['allocations']:
            self.ticket_line(row['concept']+' · '+period_label(row['period']))
            self.ticket_line('Aplicado: '+amount(row['amount']),True)
        self.y+=6;self.ticket_line('Método: '+p['method'])
        if p['reference']:self.ticket_line('Referencia: '+p['reference'])
        self.ticket_line('RECIBIDO: '+amount(p['received_amount'],'Bs' if p['currency']=='VES' else 'USD'),True,9)
        self.ticket_line('Total aplicado: '+amount(p['amount']),True)
        if p.get('balance_after') is not None:
            self.ticket_line('ABONO' if p['balance_after'] else 'PAGO COMPLETO',True)
            self.ticket_line('Deuda anterior: '+amount(p['balance_before']))
            self.ticket_line('Saldo pendiente: '+amount(p['balance_after']),True)
            self.ticket_line('Saldo del alumno al cobrar, sobre cargos registrados. No acredita solvencia.',size=7)
        else:
            self.ticket_line('Saldo histórico no registrado.',size=7)
        if p['currency']=='VES':self.ticket_line('BCV: Bs '+p['exchange_rate']+' por USD',size=7.5)
        if p['notes']:self.ticket_line('Observaciones: '+p['notes'],size=7.5)
        if p['voided']:self.ticket_line('Motivo de anulación: '+p['void_reason'],size=7.5)
        self.y+=12;self.ticket_line('Firma de administración:');self.y+=12;self.ticket_line('Firma del representante:')
        self.ticket_line('Registrado por: '+p['operator'],size=7)
        self.ticket_line('Comprobante administrativo. No sustituye una factura fiscal.',size=7)
        if len(self.pages)==1 and not self.measured:
            self.h=max(220,self.y+40)
            self.measured=True;self.pages=[];self.new_page()
            return self.render(data)
        return self.output()


class AdministrativePDF(PDF):
    embedded_fonts = True
    wrap = staticmethod(ReceiptPDF.wrap)

    def new_page(self):
        self.commands=[]; self.pages.append(self.commands)
        x=42
        if self.logo:
            w,h,_=self.logo
            self.commands.append(f'q {60*w/h:.3f} 0 0 60 42 {self.h-96} cm /Logo Do Q')
            x=115
        y=48
        if self.school.get('institution_type'):self.text(x,32,self.school['institution_type'],8,True)
        for line in self.wrap(self.school.get('legal_name') or self.school.get('school_name','Colegio'),self.w-x-42,12):
            self.text(x,y,line,12,True); y+=17
        for value in ('RIF: '+self.school.get('rif',''),self.school.get('fiscal_address') or self.school.get('address','')):
            for line in self.wrap(value,self.w-x-42,8):
                self.text(x,y,line,8); y+=12
        self.y=max(115,y+20)
        for line in self.wrap(self.title,self.w-84,12):
            self.text(42,self.y,line,12,True); self.y+=18
        self.y+=12
        self.text(self.w-100,self.h-35,f'Página {len(self.pages)}',8)


def administrative_pdf(kind,data):
    is_cash=kind=='cash-close'
    title='CIERRE DE CAJA' if is_cash else ('CONSTANCIA DE SOLVENCIA' if data['kind']=='solvency' else 'ESTADO DE CUENTA POR REPRESENTANTE')
    pdf=AdministrativePDF(f"{title} · {'C' if is_cash else 'D'}-{data['id']:06d}",data['school'])
    pdf.line('Fecha de emisión: '+data['issued_on'])
    if is_cash:
        pdf.line('Fecha cerrada: '+data['closed_on'],True)
        if data.get('reopened_at'): pdf.line('CIERRE REABIERTO: '+data['reopen_reason'],True)
        pdf.table(['Método / moneda','Ingresos recibidos','Egresos pagados','Neto'],
            [[f"{r['method']} / {r['currency']}",amount(r['income'],r['currency']),amount(r['expense'],r['currency']),signed_amount(r['net'],r['currency'])] for r in data['lines']],
            [150,123,123,123])
        pdf.line('Los importes anteriores son montos reales por moneda; no se suman dólares y bolívares.')
        pdf.table(['Efectivo','Inicial en caja','Esperado','Contado','Diferencia'],
            [[r['currency'],amount(r['opening'],r['currency']),amount(r['expected'],r['currency']),amount(r['counted'],r['currency']),signed_amount(r['difference'],r['currency'])] for r in data['counts']],
            [75,111,111,111,111])
        pdf.total(f"Equivalente USD: ingresos {amount(data['income_usd'])} | egresos {amount(data['expense_usd'])}")
        pdf.line('Arqueo: efectivo inicial + ingresos en efectivo - egresos en efectivo. El saldo bancario, pagos móviles, transferencias y tarjetas no forman parte del efectivo.')
        pdf.line('Observaciones: '+(data['notes'] or 'Sin observaciones.'))
        pdf.table(['Movimiento / referencia','Método','Moneda / recibido','Estado'],
            [[f"{'R' if r['type']=='income' else 'E'}-{r['id']:06d}\n{r['reference']}",r['method'],amount(r['received_amount'],r['currency']),'Anulado' if r['voided'] else 'Válido'] for r in data['movements']],
            [190,119,130,80])
    else:
        g=data['guardian']
        pdf.line(f"Representante: {g['name']} | Cédula: {g['document']}",True)
        if g['phone']: pdf.line('Contacto: '+g['phone'])
        pdf.table(['Alumno / código','Grado / sección','Año escolar','Estado'],
            [[f"{s['name']}\n{s['student_code']}",s['grade_name'],f"{s['school_year']}–{s['school_year']+1}",student_status(s)] for s in data['students']],
            [195,150,90,84])
        if data['kind']=='solvency':
            pdf.line('Se hace constar que los alumnos vinculados a este representante no presentan saldo pendiente en los cargos registrados al emitir este documento.',True)
            pdf.line('El corte incluye las mensualidades calculadas hasta el mes de emisión y cualquier cargo futuro ya registrado. No acredita períodos futuros que aún no estén cargados ni pagos externos sin registrar.')
            pdf.total('SALDO PENDIENTE: USD 0,00')
        else:
            pdf.total(f"Saldo pendiente: {amount(data['balance'])} | Vencido: {amount(data['overdue'])}")
            pdf.table(['Alumno / grado','Concepto / período / vence','Cargo USD','Abono USD','Saldo USD'],
                [[f"{c['student_name']}\n{c['grade_name']}",f"{c['concept']}\n{c['period']} / {c['due_date']}",amount(c['amount']),amount(c['paid']),amount(c['balance'])] for c in data['charges']],
                [150,140,76,76,77])
            pdf.line('Incluye cargos activos, pendientes y pagados, incluso períodos futuros ya preparados. La deuda vencida se calcula al emitir el documento.')
            pdf.table(['Recibo / alumno','Fecha / método','Recibido','Aplicado USD / estado'],
                [[f"R-{p['id']:06d}\n{p['student_name']}",f"{p['paid_on']}\n{p['method']}",amount(p['received_amount'],p['currency']),f"{amount(p['amount'])}\n{'Anulado' if p['voided'] else 'Válido'}"] for p in data['payments']],
                [169,120,110,120])
    pdf.line('Documento administrativo. Conserva los datos y el corte de su fecha de emisión.')
    pdf.signature('Firma de administración','Revisado por' if is_cash else 'Sello del colegio',data['operator'])
    return pdf.output()


def signed_amount(cents,currency):
    return ('- ' if cents<0 else '')+amount(abs(cents),currency)


def render_pdf(kind, data, paper='half-letter'):
    if kind in ('year-transition','payment-plan'):
        title='ACTA DE PASE DE AÑO' if kind=='year-transition' else 'CONVENIO DE PAGO'
        pdf=AdministrativePDF(f"{title} · {data['id']:06d}",data['school'])
        pdf.line('Fecha de emisión: '+data['issued_on'])
        if kind=='year-transition':
            pdf.line(f"Año {data['source_year']}–{data['source_year']+1} al {data['target_year']}–{data['target_year']+1}",True)
            pdf.line(f"Cierre del curso: {data['closed_on']} | Matrícula nueva: {data['enrollment_start']} al {data['enrollment_end']}")
            labels={'promote':'Avanza','repeat':'Repite','withdraw':'Retirado','skip':'Sin cambios'}
            pdf.table(['Alumno / código','Decisión','Grado anterior','Nuevo grado'],
                [[r['student_name']+'\n'+r['source']['student_code'],labels[r['action']],r['source_grade'],r['target_grade'] if r['action'] in ('promote','repeat') else '—'] for r in data['lines']],
                [175,85,125,134])
            pdf.line('Se conservan la matrícula anterior en esta acta, las constancias emitidas, los cargos, pagos, abonos y recibos. Los retirados quedan inactivos en el año anterior.')
        else:
            if data.get('cancelled'):pdf.line('CONVENIO CANCELADO: '+data['cancel_reason'],True)
            s=data['student'];pdf.line(s['name']+' | '+s['grade_name'],True)
            pdf.line('Representante: '+s['guardian_name']+' | '+s['guardian_document'])
            pdf.total('Deuda original convenida: '+amount(data['total']))
            pdf.table(['Cuota','Vencimiento','Importe USD'],[[r['number'],r['due_date'],amount(r['amount'])] for r in data['installments']],[85,220,214])
            pdf.line('Condiciones: '+data['notes'])
            pdf.line('El convenio organiza deuda existente; no crea cargos nuevos ni acredita pagos. Conserva sus condiciones originales. La mora se mantiene según los cargos hasta saldarlos.')
        pdf.signature('Firma de administración','Dirección' if kind=='year-transition' else 'Representante legal',data['operator'])
        return pdf.output()
    if kind in ('cash-close','guardian-document'):
        return administrative_pdf(kind,data)
    if kind == 'enrollment':
        s = data['student']; pdf = PDF(f"CONSTANCIA DE MATRÍCULA · M-{data['id']:06d}", data['school'])
        pdf.line('Fecha de emisión: '+data.get('issued_on', data['created_at'][:10]))
        for line in (f"Alumno: {s['name']}", f"Código único: {s['student_code']} | Cédula: {s['document'] if s['document']!=s['student_code'] else 'Sin cédula propia'}",
                     f"Fecha de nacimiento: {school_birth_date(s['birth_date'])}", f"Grado / sección: {s['grade_name']} | Año escolar: {s['school_year']}–{s['school_year']+1}",
                     f"Representante: {s['guardian_name']} | Cédula: {s['guardian_document']}",
                     f"Contacto: {s['guardian_phone']} | {s['guardian_email']}", f"Dirección: {s['guardian_address']}",
                     f"Período académico: {s['enrollment_start']} al {s['enrollment_end']} | Estado: {'Activo' if s['status']=='active' else 'Inactivo'}",
                     f"Mensualidades desde: {school_month(s.get('billing_start') or s['enrollment_start'][:7])}"):
            pdf.line(line)
        pdf.y += 12
        pdf.table(['Mensualidad base USD','Descuento','Mensualidad final USD'],
                  [[amount(s['monthly_fee']), f"{s['discount']} %", amount(s['net_fee'])]], [180,120,219])
        pdf.line('Observaciones: '+s['notes'])
    else:
        if paper not in ('a4','half-letter','letter-pair','ticket-58','ticket-80'):
            raise ValidationError('Formato de recibo inválido. Selecciona media carta o A4.')
        if paper=='half-letter':
            return HalfLetterReceiptPDF(data).render(data)
        if paper=='letter-pair':
            return HalfLetterReceiptPDF(data).render(data,two_copies=True)
        if paper.startswith('ticket-'):
            return TicketReceiptPDF(data,round(int(paper.split('-')[1])*72/25.4,3)).render(data)
        return ReceiptPDF(data).render(data)
    pdf.signature('Firma de administración',
                  'Firma del representante legal',
                  data.get('operator', data.get('payment',{}).get('operator','')))
    return pdf.output()
