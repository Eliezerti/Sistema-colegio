"""Administración escolar local."""
